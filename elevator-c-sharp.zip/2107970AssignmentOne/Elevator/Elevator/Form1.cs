using System.Data;

namespace Elevator
{
    public partial class Lift : Form
    {
        public Lift()
        {
            InitializeComponent();
        }

        private void btn_1_Click(object sender, EventArgs e)
        {
            btn_1.BackColor = Color.Blue;
            timer_lift_up.Enabled = true; // Set timer to move lift up
        }

        private void btn_g_Click(object sender, EventArgs e)
        {
            btn_g.BackColor = Color.Blue;
            timer_lift_down.Enabled = true; // Set timer to move lift down
        }

        private void btn_up_Click(object sender, EventArgs e)
        {
            btn_up.BackColor = Color.Blue;
            timer_lift_up.Enabled = true; // Set timer to move lift up
        }

        private void btn_down_Click(object sender, EventArgs e)
        {
            btn_down.BackColor = Color.Blue;
            timer_lift_down.Enabled = true; // Set timer to move lift down
        }

        private void timer_lift_down_Tick(object sender, EventArgs e)
        {
            LiftMove.lift_down(lift_inside); // Moves the elevator in the form
            timer_lift_down.Enabled = false;// Starts timer to move the lift down

            string date = DateTime.Now.ToShortDateString(); // Get date in a string
            string time = DateTime.Now.ToLongTimeString(); // Get time in a string

            DatabaseCommand.insertTable.Rows.Add(date, time, "Lift Going Down");

            // Set button colours back
            btn_up.BackColor = Color.White;
            btn_down.BackColor = Color.White;
            btn_1.BackColor = Color.White;
            btn_g.BackColor = Color.White;

            // Set display images
            display_panel.Image = global::Elevator.Properties.Resources.G;
            display_firstfloor.Image = global::Elevator.Properties.Resources.G;
            display_groundfloor.Image = global::Elevator.Properties.Resources.G;
            display_panel.SizeMode = PictureBoxSizeMode.StretchImage;
            display_firstfloor.SizeMode = PictureBoxSizeMode.StretchImage;
            display_groundfloor.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void timer_lift_up_Tick(object sender, EventArgs e)
        {
            LiftMove.lift_up(lift_inside); // Moves the elevator in the form
            timer_lift_up.Enabled = false; // Starts timer to move the lift up

            string date = DateTime.Now.ToShortDateString(); // Get date in a string
            string time = DateTime.Now.ToLongTimeString(); // Get time in a string
            DatabaseCommand.insertTable.Rows.Add(date, time, "Lift Going Up");

            // Set button colours back
            btn_up.BackColor = Color.White;
            btn_down.BackColor = Color.White;
            btn_1.BackColor = Color.White;
            btn_g.BackColor = Color.White;

            // Set display images
            display_panel.Image = global::Elevator.Properties.Resources._1;
            display_firstfloor.Image = global::Elevator.Properties.Resources._1;
            display_groundfloor.Image = global::Elevator.Properties.Resources._1;
            display_panel.SizeMode = PictureBoxSizeMode.StretchImage;
            display_firstfloor.SizeMode = PictureBoxSizeMode.StretchImage;
            display_groundfloor.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void viewDB_Click(object sender, EventArgs e)
        {
            // Loads new form for tables
            ViewDB form = new();
            form.Show();
        }

        private void saveDB_Click(object sender, EventArgs e)
        {
            new Thread(() => //which thread has a property called isBackground
            {
                Thread.CurrentThread.IsBackground = true; // do not prevent a process from termiating
                DatabaseCommand.InsertData();
            }).Start();
        }
    }
}
