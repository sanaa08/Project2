﻿namespace Elevator
{
    partial class Lift
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Lift));
            this.lift_firstfloor = new System.Windows.Forms.PictureBox();
            this.lift_groundfloor = new System.Windows.Forms.PictureBox();
            this.lift_inside = new System.Windows.Forms.PictureBox();
            this.panel = new System.Windows.Forms.PictureBox();
            this.display_panel = new System.Windows.Forms.PictureBox();
            this.display_firstfloor = new System.Windows.Forms.PictureBox();
            this.display_groundfloor = new System.Windows.Forms.PictureBox();
            this.btn_1 = new System.Windows.Forms.Button();
            this.btn_g = new System.Windows.Forms.Button();
            this.btn_up = new System.Windows.Forms.Button();
            this.btn_down = new System.Windows.Forms.Button();
            this.timer_lift_down = new System.Windows.Forms.Timer(this.components);
            this.timer_lift_up = new System.Windows.Forms.Timer(this.components);
            this.viewDB = new System.Windows.Forms.Button();
            this.saveDB = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.lift_firstfloor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lift_groundfloor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lift_inside)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.display_panel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.display_firstfloor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.display_groundfloor)).BeginInit();
            this.SuspendLayout();
            // 
            // lift_firstfloor
            // 
            this.lift_firstfloor.Image = ((System.Drawing.Image)(resources.GetObject("lift_firstfloor.Image")));
            this.lift_firstfloor.Location = new System.Drawing.Point(122, 25);
            this.lift_firstfloor.Name = "lift_firstfloor";
            this.lift_firstfloor.Size = new System.Drawing.Size(378, 415);
            this.lift_firstfloor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.lift_firstfloor.TabIndex = 0;
            this.lift_firstfloor.TabStop = false;
            // 
            // lift_groundfloor
            // 
            this.lift_groundfloor.Image = ((System.Drawing.Image)(resources.GetObject("lift_groundfloor.Image")));
            this.lift_groundfloor.Location = new System.Drawing.Point(122, 466);
            this.lift_groundfloor.Name = "lift_groundfloor";
            this.lift_groundfloor.Size = new System.Drawing.Size(378, 417);
            this.lift_groundfloor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.lift_groundfloor.TabIndex = 1;
            this.lift_groundfloor.TabStop = false;
            // 
            // lift_inside
            // 
            this.lift_inside.Image = ((System.Drawing.Image)(resources.GetObject("lift_inside.Image")));
            this.lift_inside.Location = new System.Drawing.Point(195, 559);
            this.lift_inside.Name = "lift_inside";
            this.lift_inside.Size = new System.Drawing.Size(231, 241);
            this.lift_inside.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.lift_inside.TabIndex = 2;
            this.lift_inside.TabStop = false;
            // 
            // panel
            // 
            this.panel.Image = ((System.Drawing.Image)(resources.GetObject("panel.Image")));
            this.panel.Location = new System.Drawing.Point(612, 116);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(251, 684);
            this.panel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.panel.TabIndex = 7;
            this.panel.TabStop = false;
            // 
            // display_panel
            // 
            this.display_panel.BackgroundImage = global::Elevator.Properties.Resources.black;
            this.display_panel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.display_panel.Location = new System.Drawing.Point(658, 161);
            this.display_panel.Name = "display_panel";
            this.display_panel.Size = new System.Drawing.Size(157, 148);
            this.display_panel.TabIndex = 8;
            this.display_panel.TabStop = false;
            // 
            // display_firstfloor
            // 
            this.display_firstfloor.Image = ((System.Drawing.Image)(resources.GetObject("display_firstfloor.Image")));
            this.display_firstfloor.Location = new System.Drawing.Point(257, 45);
            this.display_firstfloor.Name = "display_firstfloor";
            this.display_firstfloor.Size = new System.Drawing.Size(108, 45);
            this.display_firstfloor.TabIndex = 9;
            this.display_firstfloor.TabStop = false;
            // 
            // display_groundfloor
            // 
            this.display_groundfloor.Image = ((System.Drawing.Image)(resources.GetObject("display_groundfloor.Image")));
            this.display_groundfloor.Location = new System.Drawing.Point(257, 481);
            this.display_groundfloor.Name = "display_groundfloor";
            this.display_groundfloor.Size = new System.Drawing.Size(108, 53);
            this.display_groundfloor.TabIndex = 10;
            this.display_groundfloor.TabStop = false;
            // 
            // btn_1
            // 
            this.btn_1.Image = ((System.Drawing.Image)(resources.GetObject("btn_1.Image")));
            this.btn_1.Location = new System.Drawing.Point(676, 353);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(118, 120);
            this.btn_1.TabIndex = 11;
            this.btn_1.UseVisualStyleBackColor = true;
            this.btn_1.Click += new System.EventHandler(this.btn_1_Click);
            // 
            // btn_g
            // 
            this.btn_g.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_g.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_g.Image = ((System.Drawing.Image)(resources.GetObject("btn_g.Image")));
            this.btn_g.Location = new System.Drawing.Point(676, 497);
            this.btn_g.Name = "btn_g";
            this.btn_g.Size = new System.Drawing.Size(118, 130);
            this.btn_g.TabIndex = 12;
            this.btn_g.UseVisualStyleBackColor = true;
            this.btn_g.Click += new System.EventHandler(this.btn_g_Click);
            // 
            // btn_up
            // 
            this.btn_up.Image = ((System.Drawing.Image)(resources.GetObject("btn_up.Image")));
            this.btn_up.Location = new System.Drawing.Point(506, 258);
            this.btn_up.Name = "btn_up";
            this.btn_up.Size = new System.Drawing.Size(102, 114);
            this.btn_up.TabIndex = 15;
            this.btn_up.UseVisualStyleBackColor = true;
            this.btn_up.Click += new System.EventHandler(this.btn_up_Click);
            // 
            // btn_down
            // 
            this.btn_down.Image = ((System.Drawing.Image)(resources.GetObject("btn_down.Image")));
            this.btn_down.Location = new System.Drawing.Point(506, 630);
            this.btn_down.Name = "btn_down";
            this.btn_down.Size = new System.Drawing.Size(100, 109);
            this.btn_down.TabIndex = 16;
            this.btn_down.UseVisualStyleBackColor = true;
            this.btn_down.Click += new System.EventHandler(this.btn_down_Click);
            // 
            // timer_lift_down
            // 
            this.timer_lift_down.Tick += new System.EventHandler(this.timer_lift_down_Tick);
            // 
            // timer_lift_up
            // 
            this.timer_lift_up.Tick += new System.EventHandler(this.timer_lift_up_Tick);
            // 
            // viewDB
            // 
            this.viewDB.Location = new System.Drawing.Point(640, 667);
            this.viewDB.Name = "viewDB";
            this.viewDB.Size = new System.Drawing.Size(187, 34);
            this.viewDB.TabIndex = 17;
            this.viewDB.Text = "Load Database";
            this.viewDB.UseVisualStyleBackColor = true;
            this.viewDB.Click += new System.EventHandler(this.viewDB_Click);
            // 
            // saveDB
            // 
            this.saveDB.Location = new System.Drawing.Point(640, 723);
            this.saveDB.Name = "saveDB";
            this.saveDB.Size = new System.Drawing.Size(187, 34);
            this.saveDB.TabIndex = 18;
            this.saveDB.Text = "Save Database";
            this.saveDB.UseVisualStyleBackColor = true;
            this.saveDB.Click += new System.EventHandler(this.saveDB_Click);
            // 
            // Lift
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(992, 895);
            this.Controls.Add(this.saveDB);
            this.Controls.Add(this.viewDB);
            this.Controls.Add(this.btn_down);
            this.Controls.Add(this.btn_up);
            this.Controls.Add(this.btn_g);
            this.Controls.Add(this.btn_1);
            this.Controls.Add(this.display_groundfloor);
            this.Controls.Add(this.display_firstfloor);
            this.Controls.Add(this.display_panel);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.lift_inside);
            this.Controls.Add(this.lift_groundfloor);
            this.Controls.Add(this.lift_firstfloor);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Lift";
            this.Text = "Lift";
            ((System.ComponentModel.ISupportInitialize)(this.lift_firstfloor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lift_groundfloor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lift_inside)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.display_panel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.display_firstfloor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.display_groundfloor)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private PictureBox lift_firstfloor;
        private PictureBox lift_groundfloor;
        private PictureBox lift_inside;
        private PictureBox panel;
        private PictureBox display_panel;
        private PictureBox display_firstfloor;
        private PictureBox display_groundfloor;
        private Button btn_1;
        private Button btn_g;
        private Button btn_up;
        private Button btn_down;
        private System.Windows.Forms.Timer timer_lift_down;
        private System.Windows.Forms.Timer timer_lift_up;
        private Button viewDB;
        private Button saveDB;
    }
}