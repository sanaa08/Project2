﻿using System.Data;
using System.Data.OleDb;


namespace Elevator
{
    class DatabaseCommand
    {
        public static DataTable insertTable = new();

        public static void AddColumns()
        {
            insertTable.Columns.Add("Date", typeof(string));
            insertTable.Columns.Add("Time", typeof(string));
            insertTable.Columns.Add("Actions", typeof(string));
        }

        public static OleDbConnection GetConn()
        {
            return new("Provider = Microsoft.ACE.OLEDB.12.0; Data Source = records.accdb;");
        }
        public static void InsertData()
        {
            OleDbConnection conn = GetConn(); // Gets connection
            conn.Open(); // Opens connection
            OleDbDataAdapter dataAdapter = new()
            {
                InsertCommand = new OleDbCommand("insert into [ElevatorRecord] " +
                "([Date],[Time],[Actions]) " +
                "values (?, ?, ?)", conn)
            };

            dataAdapter.InsertCommand.Parameters.Add("Date", OleDbType.VarChar, 10, "Date");
            dataAdapter.InsertCommand.Parameters.Add("Time", OleDbType.VarChar, 8, "Time");
            dataAdapter.InsertCommand.Parameters.Add("Actions", OleDbType.VarChar, 20, "Actions"); // Set parameters for SQL command
            dataAdapter.Update(insertTable); // Execute SQL command
            conn.Close(); // Close connection
        }

        public static DataTable ViewData() //method to view the database record
        {
            OleDbConnection conn = GetConn();
            conn.Open(); // Open connection
            OleDbDataAdapter da = new("SELECT date, time, actions FROM ElevatorRecord", GetConn()); // Create a data adapter to read from database
            DataSet ds = new(); // Make a new dataset
            da.Fill(ds, "ElevatorRecord"); // Fill dataset with info from database
            conn.Close(); // Close connection
            return ds.Tables[0]; // Return the dataset to wherever method was called
        }
    }
}