﻿namespace Elevator
{
    class LiftMove
    {
        public static void lift_down(PictureBox lift_inside)
        {
            while(lift_inside.Top <= 559)
            {
                lift_inside.Top += 1; // Move elevator down 1 pixel on every loop
            }
        }

        public static void lift_up(PictureBox lift_inside)
        {
            while(lift_inside.Top >= 116)
            {
                lift_inside.Top -= 1; // Move elevator up 1 pixel on every loop
            }
        }
    }
}
