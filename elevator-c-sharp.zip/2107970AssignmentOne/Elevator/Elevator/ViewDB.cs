﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Elevator
{
    public partial class ViewDB : Form
    {
        public ViewDB()
        {
            DataGridView dataGridView = new() // Configures data table 
            {
                Dock = DockStyle.Fill,
                Size = new Size(500, 250),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells,
                AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize,
                DataSource = DatabaseCommand.ViewData() // Get data from database using a method
            };
            Controls.Add(dataGridView); // Adds data table to the form

            InitializeComponent();
        }
    }
}
